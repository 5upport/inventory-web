<?php
$page_title = 'Edit Item';
require_once('includes/load.php');
page_require_level(2);
?>
<?php
$items = find_by_id('itemss', (int)$_GET['id']);
$all_categories = find_all('categories');
$all_photo = find_all('media');
if (!$items) {
  $session->msg("d", "Missing items id.");
  redirect('items.php');
}
?>
<?php
if (isset($_POST['items'])) {
  $req_fields = array('items-title', 'items-categorie', 'items-quantity', 'items-nomat', 'items-type');
  validate_fields($req_fields);
  if (empty($errors)) {
    $p_name  = remove_junk($db->escape($_POST['items-title']));
    $p_cat   = (int)$_POST['items-categorie'];
    $p_qty   = remove_junk($db->escape($_POST['items-quantity']));
    $p_nomat  = remove_junk($db->escape($_POST['items-nomat']));
    $p_type  = remove_junk($db->escape($_POST['items-type']));
    if (is_null($_POST['items-photo']) || $_POST['items-photo'] === "") {
      $media_id = '0';
    } else {
      $media_id = remove_junk($db->escape($_POST['items-photo']));
    }
    $query   = "UPDATE itemss SET";
    $query  .= " name ='{$p_name}', quantity ='{$p_qty}', nomat ='{$p_nomat}', type ='{$p_type}',";
    $query  .= " buy_price ='{$p_buy}', exitItem_price ='{$p_exitItem}', categorie_id ='{$p_cat}',media_id='{$media_id}'";
    $query  .= " WHERE id ='{$items['id']}'";
    $result = $db->query($query);
    if ($result && $db->affected_rows() === 1) {
      $session->msg('s', "Items updated ");
      redirect('items.php', false);
    } else {
      $session->msg('d', ' Sorry failed to updated!');
      redirect('edit_items.php?id=' . $items['id'], false);
    }
  } else {
    $session->msg("d", $errors);
    redirect('edit_items.php?id=' . $items['id'], false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="panel panel-default">
    <div class="panel-heading">
      <strong>
        <span class="glyphicon glyphicon-th"></span>
        <span>Edit Item</span>
      </strong>
    </div>
    <div class="panel-body">
      <div class="col-md-7">
        <form method="post" action="edit_items.php?id=<?php echo (int)$items['id'] ?>">
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-tag"></i>
              </span>
              <input type="text" class="form-control" name="items-title" value="<?php echo remove_junk($items['name']); ?>">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-text-background"></i>
              </span>
              <input type="text" class="form-control" name="items-nomat" value="<?php echo remove_junk($items['nomat']); ?>">
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <span class="input-group-addon">
                <i class="glyphicon glyphicon-edit"></i>
              </span>
              <input type="text" class="form-control" name="items-type" value="<?php echo remove_junk($items['type']); ?>">
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-md-6">
                <select class="form-control" name="items-categorie">
                  <option value=""> Select a categorie</option>
                  <?php foreach ($all_categories as $cat) : ?>
                    <option value="<?php echo (int)$cat['id']; ?>" <?php if ($items['categorie_id'] === $cat['id']) : echo "selected";
                                                                    endif; ?>>
                      <?php echo remove_junk($cat['name']); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6">
                <select class="form-control" name="items-photo">
                  <option value=""> No image</option>
                  <?php foreach ($all_photo as $photo) : ?>
                    <option value="<?php echo (int)$photo['id']; ?>" <?php if ($items['media_id'] === $photo['id']) : echo "selected";
                                                                      endif; ?>>
                      <?php echo $photo['file_name'] ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label for="qty">Quantity</label>
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-qrcode"></i>
                    </span>
                    <input type="number" class="form-control" name="items-quantity" value="<?php echo remove_junk($items['quantity']); ?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <button type="submit" name="items" class="btn btn-danger">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>