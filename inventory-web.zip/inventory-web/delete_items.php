<?php
require_once('includes/load.php');
page_require_level(2);
?>
<?php
$items = find_by_id('itemss', (int)$_GET['id']);
if (!$items) {
  $session->msg("d", "Missing Items id.");
  redirect('items.php');
}
?>
<?php
$delete_id = delete_by_id('itemss', (int)$items['id']);
if ($delete_id) {
  $session->msg("s", "item deleted.");
  redirect('items.php');
} else {
  $session->msg("d", "item deletion failed.");
  redirect('items.php');
}
?>
