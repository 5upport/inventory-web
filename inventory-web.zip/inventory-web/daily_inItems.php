<?php
$page_title = 'Daily';
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$year  = date('Y');
$month = date('m');
$inItems = dailyinItem($year, $month);
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-share"></span>
          <span>Daily</span>
        </strong>
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th> Item name </th>
              <th class="text-center" style="width: 15%;"> Quantity out</th>
              <!-- <th class="text-center" style="width: 15%;"> Total </th> -->
              <th class="text-center" style="width: 15%;"> Date </th>
              <th class="text-center" style="width: 15%;"> Remarks </th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($inItems as $inItem) : ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk($inItem['name']); ?></td>
                <td class="text-center"><?php echo (int)$inItem['qty']; ?></td>
                <!-- <td class="text-center"><?php echo remove_junk($inItem['total_saleing_price']); ?></td> -->
                <td class="text-center"><?php echo $inItem['date']; ?></td>
                <td class="text-center"><?php echo remove_junk($inItem['rmk']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>