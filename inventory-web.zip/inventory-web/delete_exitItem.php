<?php
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$d_exitItem = find_by_id('exitItems', (int)$_GET['id']);
if (!$d_exitItem) {
  $session->msg("d", "Missing exitItem id.");
  redirect('exitItems.php');
}
?>
<?php
$delete_id = delete_by_id('exitItems', (int)$d_exitItem['id']);
if ($delete_id) {
  $session->msg("s", "item deleted.");
  redirect('exitItems.php');
} else {
  $session->msg("d", "exitItem deletion failed.");
  redirect('exitItems.php');
}
?>
