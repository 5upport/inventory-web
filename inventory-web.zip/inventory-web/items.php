<?php
$page_title = 'All';
require_once('includes/load.php');
page_require_level(2);
$itemss = join_items_table();
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <div class="pull-right">
          <a href="add_items.php" class="btn btn-primary">Add New</a>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th> Photo</th>
              <th> Item Name </th>
              <th class="text-center" style="width: 10%;"> Categorie </th>
              <th class="text-center" style="width: 10%;"> Instock </th>
              <th class="text-center" style="width: 10%;"> Item Added </th>
              <th class="text-center" style="width: 10%;"> Nomat </th>
              <th class="text-center" style="width: 10%;"> Type </th>
              <th class="text-center" style="width: 100px;"> Actions </th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($itemss as $items) : ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td>
                  <?php if ($items['media_id'] === '0') : ?>
                    <img class="img-avatar img-circle" src="uploads/itemss/no_image.jpg" alt="">
                  <?php else : ?>
                    <img class="img-avatar img-circle" src="uploads/itemss/<?php echo $items['image']; ?>" alt="">
                  <?php endif; ?>
                </td>
                <td> <?php echo remove_junk($items['name']); ?></td>
                <td class="text-center"> <?php echo remove_junk($items['categorie']); ?></td>
                <td class="text-center"> <?php echo remove_junk($items['quantity']); ?></td>
                <!-- <td class="text-center"> <?php echo $items['date']; ?></td> -->
                <td class="text-center"> <?php $date = new DateTime($items['date'], new DateTimeZone('UTC'));
                                          $date->setTimezone(new DateTimeZone('Asia/Jakarta'));
                                          $date->modify('-1 hour');
                                          echo $date->format('F j, Y, g:i:s a');
                                          ?></td>
                <td class="text-center"> <?php echo remove_junk($items['nomat']); ?></td>
                <td class="text-center"> <?php echo remove_junk($items['type']); ?></td>
                <td class="text-center">
                  <div class="btn-group">
                    <a href="edit_items.php?id=<?php echo (int)$items['id']; ?>" class="btn btn-info btn-xs" title="Edit" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="delete_items.php?id=<?php echo (int)$items['id']; ?>" class="btn btn-danger btn-xs" title="Delete" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
          </tabel>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>