<?php
/*
|--------------------------------------------------------------------------
| INV V2
|--------------------------------------------------------------------------
| Project Name: INV
| Version: v2
|
|
|
*/
define('DB_HOST', 'localhost');          // Set database host
define('DB_USER', 'root');             // Set database user
define('DB_PASS', '');             // Set database password
define('DB_NAME', 'dtbase_inv');        // Set database name
