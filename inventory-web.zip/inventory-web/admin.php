<?php
$page_title = 'Home';
require_once('includes/load.php');
page_require_level(1);
?>
<?php
$c_categorie      = count_by_id('categories');
$c_items          = count_by_id('itemss');
$c_inItem         = count_by_id('inItems');
$c_exitItem       = count_by_id('exitItems');
$c_user           = count_by_id('users');
$itemss_sold      = find_higest_saleing_items('10');
$recent_itemss    = find_recent_items_added('5');
$recent_exitItems = find_recent_exitItem_added('5')
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-inbox"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_items['total']; ?> </h2>
        <p class="text-muted">IN STOCK</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-log-in"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_inItem['total']; ?></h2>
        <p class="text-muted">ITEM RECEIVED</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-log-out"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_exitItem['total']; ?></h2>
        <p class="text-muted">ITEM OUT</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-tag"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_categorie['total']; ?> </h2>
        <p class="text-muted">CATEGORIES</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-eye-open"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_user['total']; ?> </h2>
        <p class="text-muted">USERS</p>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>