<?php
$page_title = 'Home';
require_once('includes/load.php');
page_require_level(1);
?>
<?php
$c_categorie     = count_by_id('categories');
$c_items       = count_by_id('itemss');
$c_exitItem          = count_by_id('exitItems');
$c_user          = count_by_id('users');
$itemss_sold   = find_higest_saleing_items('10');
$recent_itemss = find_recent_items_added('5');
$recent_exitItems    = find_recent_exitItem_added('5')
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-green">
        <i class="glyphicon glyphicon-menu-hamburger"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_user['total']; ?> </h2>
        <p class="text-muted">Users</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-yellow">
        <i class="glyphicon glyphicon-list-alt"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_categorie['total']; ?> </h2>
        <p class="text-muted">Categories</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-blue">
        <i class="glyphicon glyphicon-import"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_items['total']; ?> </h2>
        <p class="text-muted">In</p>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-box clearfix">
      <div class="panel-icon pull-left bg-red">
        <i class="glyphicon glyphicon-export"></i>
      </div>
      <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php echo $c_exitItem['total']; ?></h2>
        <p class="text-muted">Out</p>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>