<?php
$page_title = 'Edit item';
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$bundlingItem = find_by_id('bundlingItems', (int)$_GET['id']);
if (!$bundlingItem) {
  $session->msg("d", "Missing items id.");
  redirect('bundlingItems.php');
}
?>
<?php $items = find_by_id('itemss', $bundlingItem['items_id']); ?>
<?php
if (isset($_POST['update_bundlingItem'])) {
  $req_fields = array('title', 'quantity', 'date');
  validate_fields($req_fields);
  if (empty($errors)) {
    $p_id      = $db->escape((int)$items['id']);
    $s_qty     = $db->escape((int)$_POST['quantity']);
    $date      = $db->escape($_POST['date']);
    $s_date    = date("Y-m-d", strtotime($date));
    $s_rmk     = $db->escape($_POST['remarks']);
    $sql  = "UPDATE bundlingItems SET";
    $sql .= " items_id= '{$p_id}',qty={$s_qty},price='{$s_total}',date='{$s_date}',rmk='{$s_rmk}'";
    $sql .= " WHERE id ='{$bundlingItem['id']}'";
    $result = $db->query($sql);
    if ($result && $db->affected_rows() === 1) {
      update_items_qty($s_qty, $p_id);
      $session->msg('s', "bundlingItem updated.");
      redirect('edit_bundlingItem.php?id=' . $bundlingItem['id'], false);
    } else {
      $session->msg('d', ' Sorry failed to updated!');
      redirect('bundlingItems.php', false);
    }
  } else {
    $session->msg("d", $errors);
    redirect('edit_bundlingItem.php?id=' . (int)$bundlingItem['id'], false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>All </span>
        </strong>
        <div class="pull-right">
          <a href="bundlingItems.php" class="btn btn-primary">Show all</a>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <th> Item title </th>
            <th> Qty </th>
            <th> Date</th>
            <th> Action</th>
            <th> Remarks</th>
          </thead>
          <tbody id="items_info">
            <tr>
              <form method="post" action="edit_bundlingItem.php?id=<?php echo (int)$bundlingItem['id']; ?>">
                <td id="s_name">
                  <input type="text" class="form-control" id="sug_input" name="title" value="<?php echo remove_junk($items['name']); ?>">
                  <div id="result" class="list-group"></div>
                </td>
                <td id="s_qty">
                  <input type="text" class="form-control" name="quantity" value="<?php echo (int)$bundlingItem['qty']; ?>">
                </td>
                <td id="s_date">
                  <input type="date" class="form-control" name="date" data-date-format="" value="<?php echo remove_junk($bundlingItem['date']); ?>">
                </td>
                <td>
                  <button type="submit" name="update_bundlingItem" class="btn btn-primary">Update Item</button>
                </td>
                <td id="s_rmk">
                  <input type="text" class="form-control" name="remarks" value="<?php echo remove_junk($bundlingItem['rmk']); ?>">
                </td>
              </form>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>