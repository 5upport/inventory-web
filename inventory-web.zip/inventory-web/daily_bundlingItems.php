<?php
$page_title = 'Daily';
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$year  = date('Y');
$month = date('m');
$exitItems = dailyexitItem($year, $month);
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-share"></span>
          <span>Daily</span>
        </strong>
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th> Item name </th>
              <th class="text-center" style="width: 15%;"> Quantity out</th>
              <!-- <th class="text-center" style="width: 15%;"> Total </th> -->
              <th class="text-center" style="width: 15%;"> Date </th>
              <th class="text-center" style="width: 15%;"> Remarks </th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($exitItems as $exitItem) : ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk($exitItem['name']); ?></td>
                <td class="text-center"><?php echo (int)$exitItem['qty']; ?></td>
                <!-- <td class="text-center"><?php echo remove_junk($exitItem['total_saleing_price']); ?></td> -->
                <td class="text-center"><?php echo $exitItem['date']; ?></td>
                <td class="text-center"><?php echo remove_junk($exitItem['rmk']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>