<?php
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$d_inItem = find_by_id('inItems', (int)$_GET['id']);
if (!$d_inItem) {
  $session->msg("d", "Missing inItem id.");
  redirect('inItems.php');
}
?>
<?php
$delete_id = delete_by_id('inItems', (int)$d_inItem['id']);
if ($delete_id) {
  $session->msg("s", "item deleted.");
  redirect('inItems.php');
} else {
  $session->msg("d", "inItem deletion failed.");
  redirect('inItems.php');
}
?>
