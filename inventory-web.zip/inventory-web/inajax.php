<?php
require_once('includes/load.php');
if (!$session->isUserLoggedIn(true)) {
  redirect('index.php', false);
}
?>
<?php
$html = '';
if (isset($_POST['items_name']) && strlen($_POST['items_name'])) {
  $itemss = find_items_by_title($_POST['items_name']);
  if ($itemss) {
    foreach ($itemss as $items) :
      $html .= "<li class=\"list-group-item\">";
      $html .= $items['name'];
      $html .= "</li>";
    endforeach;
  } else {
    $html .= '<li onClick=\"fill(\'' . addslashes() . '\')\" class=\"list-group-item\">';
    $html .= 'Not found';
    $html .= "</li>";
  }
  echo json_encode($html);
}
?>
 <?php
  // find all items
  if (isset($_POST['p_name']) && strlen($_POST['p_name'])) {
    $items_title = remove_junk($db->escape($_POST['p_name']));
    if ($results = find_all_items_info_by_title($items_title)) {
      foreach ($results as $result) {
        $html .= "<tr>";
        $html .= "<td id=\"s_name\">" . $result['name'] . "</td>";
        $html .= "<input type=\"hidden\" name=\"s_id\" value=\"{$result['id']}\">";
        $html .= "<td id=\"s_qty\">";
        $html .= "<input type=\"text\" class=\"form-control\" name=\"quantity\" value=\"1\">";
        $html  .= "</td>";
        $html  .= "<td>";
        $html  .= "<input type=\"date\" class=\"form-control\" name=\"date\" data-date-format=\"dd-mm-yyyy\">";
        $html  .= "</td>";
        $html  .= "<td id=\"s_rmk\">";
        $html  .= "<input type=\"text\" class=\"form-control\" name=\"remarks\" value=\"\">";
        $html  .= "</td>";
        $html  .= "<td>";
        $html  .= "<button type=\"submit\" name=\"add_inItem\" class=\"btn btn-primary\">Add Items</button>";
        $html  .= "</td>";
        $html  .= "</tr>";
      }
    } else {
      $html = '<tr><td>item name not register in database</td></tr>';
    }
    echo json_encode($html);
  }
  ?>
