<?php
$page_title = 'Add';
require_once('includes/load.php');
page_require_level(2);
$all_categories = find_all('categories');
$all_photo = find_all('media');
?>
<?php
if (isset($_POST['add_items'])) {
  $req_fields = array('items-title', 'items-categorie', 'items-quantity', 'items-nomat', 'items-type');
  validate_fields($req_fields);
  if (empty($errors)) {
    $p_name  = remove_junk($db->escape($_POST['items-title']));
    $p_cat   = remove_junk($db->escape($_POST['items-categorie']));
    $p_qty   = remove_junk($db->escape($_POST['items-quantity']));
    $p_nomat  = remove_junk($db->escape($_POST['items-nomat']));
    $p_type  = remove_junk($db->escape($_POST['items-type']));
    if (is_null($_POST['items-photo']) || $_POST['items-photo'] === "") {
      $media_id = '0';
    } else {
      $media_id = remove_junk($db->escape($_POST['items-photo']));
    }
    $date    = make_date();
    $query  = "INSERT INTO itemss (";
    $query .= " name,quantity,buy_price,exitItem_price,categorie_id,media_id,date,nomat,type";
    $query .= ") VALUES (";
    $query .= " '{$p_name}', '{$p_qty}', '{$p_buy}', '{$p_exitItem}', '{$p_cat}', '{$media_id}', '{$date}', '{$p_nomat}', '{$p_type}'";
    $query .= ")";
    $query .= " ON DUPLICATE KEY UPDATE name='{$p_name}'";
    if ($db->query($query)) {
      $session->msg('s', "item added ");
      redirect('add_items.php', false);
    } else {
      $session->msg('d', ' Sorry failed to added!');
      redirect('items.php', false);
    }
  } else {
    $session->msg("d", $errors);
    redirect('add_items.php', false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-8">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-share"></span>
          <span>Add New Item</span>
        </strong>
      </div>
      <div class="panel-body">
        <div class="col-md-12">
          <form method="post" action="add_items.php" class="clearfix">
            <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon">
                  <i class="glyphicon glyphicon-tag"></i>
                </span>
                <input type="text" class="form-control" name="items-title" placeholder="Item Name">
              </div>
            </div>
            <div class="form-group">
              <div class="row">
                <div class="col-md-6">
                  <select class="form-control" name="items-categorie">
                    <option value="">-- Select Category --</option>
                    <?php foreach ($all_categories as $cat) : ?>
                      <option value="<?php echo (int)$cat['id'] ?>">
                        <?php echo $cat['name'] ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <select class="form-control" name="items-photo">
                    <option value="">-- Select Photo --</option>
                    <?php foreach ($all_photo as $photo) : ?>
                      <option value="<?php echo (int)$photo['id'] ?>">
                        <?php echo $photo['file_name'] ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="row">
                <div class="col-md-4">
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-qrcode"></i>
                    </span>
                    <input type="number" class="form-control" name="items-quantity" placeholder="Item Quantity">
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="row">
                <div class="col-md-6">
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-text-background"></i>
                    </span>
                    <input type="number" class="form-control" name="items-nomat" placeholder="Item Nomat">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-edit"></i>
                    </span>
                    <input type="text" class="form-control" name="items-type" placeholder="Item Type">
                  </div>
                </div>
              </div>
            </div>
            <button type="submit" name="add_items" class="btn btn-danger">Add Item</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>