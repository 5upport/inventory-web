<?php
$page_title = 'All';
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$bundlingItems = find_all_bundlingItem();
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-share"></span>
          <span>All</span>
        </strong>
        <div class="pull-right">
          <a href="add_bundlingItem.php" class="btn btn-primary">Add</a>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th class="text-center" style="width: 50px;">#</th>
              <th> Item name </th>
              <th class="text-center" style="width: 15%;"> Quantity</th>
              <th class="text-center" style="width: 15%;"> Date </th>
              <th class="text-center" style="width: 15%;"> Remarks </th>
              <th class="text-center" style="width: 100px;"> Actions </th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bundlingItems as $bundlingItem) : ?>
              <tr>
                <td class="text-center"><?php echo count_id(); ?></td>
                <td><?php echo remove_junk($bundlingItem['name']); ?></td>
                <td class="text-center"><?php echo (int)$bundlingItem['qty']; ?></td>
                <td class="text-center"><?php echo $bundlingItem['date']; ?></td>
                <td class="text-center"> <?php echo remove_junk($bundlingItem['rmk']); ?></td>
                <td class="text-center">
                  <div class="btn-group">
                    <a href="edit_bundlingItem.php?id=<?php echo (int)$bundlingItem['id']; ?>" class="btn btn-warning btn-xs" title="Edit" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="delete_bundlingItem.php?id=<?php echo (int)$bundlingItem['id']; ?>" class="btn btn-danger btn-xs" title="Delete" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>