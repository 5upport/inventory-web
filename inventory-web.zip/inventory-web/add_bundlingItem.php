<?php
$page_title = 'Add';
require_once('includes/load.php');
page_require_level(3);

// Proses ketika tombol "Submit Bundling" ditekan
if (isset($_POST['add_bundlingItem'])) {
  // Validasi input
  $req_fields = array('s_id', 'quantity', 'date', 'remarks');
  validate_fields($req_fields);

  // Pastikan tidak ada kesalahan validasi
  if (empty($errors)) {
    // Loop untuk mengolah setiap item yang dikirimkan melalui form
    for ($i = 0; $i < count($_POST['s_id']); $i++) {
      $p_id      = $db->escape((int)$_POST['s_id'][$i]);
      $s_qty     = $db->escape((int)$_POST['quantity'][$i]);
      $s_date    = date("Y-m-d", strtotime($_POST['date'][$i])); // Format tanggal Y-m-d
      $s_rmk     = isset($_POST['remarks'][$i]) ? $db->escape($_POST['remarks'][$i]) : ''; // Keterangan

      // Query untuk menyimpan data ke tabel bundlingItems
      $sql = "INSERT INTO bundlingItems (items_id, qty, date, rmk) 
              VALUES ('{$p_id}', '{$s_qty}', '{$s_date}', '{$s_rmk}')";

      // Eksekusi query
      if ($db->query($sql)) {
        // Jika data berhasil disimpan, update kuantitas barang
        update_items_qty($s_qty, $p_id);
      } else {
        $session->msg('d', 'Sorry, failed to add bundling item!');
        redirect('add_bundlingItem.php', false);
        exit; // Keluar jika ada kegagalan
      }
    }

    // Tampilkan pesan sukses jika semua item berhasil ditambahkan
    $session->msg('s', 'Bundling items added successfully.');
    redirect('add_bundlingItem.php', false);
  } else {
    // Tampilkan pesan error jika ada kesalahan validasi
    $session->msg('d', $errors);
    redirect('add_bundlingItem.php', false);
  }
}
?>


<?php include_once('layouts/header.php'); ?>

<!-- Search Form -->
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
    <form method="post" action="ajax.php" autocomplete="off" id="sug-form">
      <div class="form-group">
        <div class="input-group">
          <span class="input-group-btn">
            <button type="button" class="btn btn-primary" id="search-btn">Find It</button>
          </span>
          <input type="text" id="sug_input" class="form-control" name="title" placeholder="Search for item name">
        </div>
        <div id="result" class="list-group"></div>
      </div>
    </form>
  </div>
</div>

<!-- Bundling Table -->
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-share"></span>
          <span>Add Items to Bundling</span>
        </strong>
      </div>
      <div class="panel-body">
        <form method="post" action="add_bundlingItem.php">
          <table class="table table-bordered">
            <thead>
              <th> Item </th>
              <th> Qty </th>
              <th> Date </th>
              <th> Remarks </th>
              <th> Action </th>
            </thead>
            <tbody id="items_info"> </tbody>
          </table>
          <button type="submit" name="add_bundlingItem" class="btn btn-success">Submit Bundling</button>
        </form>

      </div>
    </div>
  </div>
</div>

<?php include_once('layouts/footer.php'); ?>

<!-- AJAX + JS -->
<script>
  // Handle the search functionality
  // Handle the search functionality
  $('#search-btn').click(function() {
    var query = $('#sug_input').val();
    if (query) {
      $.ajax({
        url: 'ajax.php', // Pastikan skrip ini menangani logika pencarian
        method: 'POST',
        data: {
          title: query
        },
        success: function(data) {
          $('#result').html(data); // Menampilkan hasil pencarian
        }
      });
    }
  });

  // Handle selecting an item from search results
  $(document).on('click', '.list-group-item', function() {
    var itemId = $(this).data('id');
    var itemName = $(this).text(); // Nama item yang dipilih
    var row = '<tr>';
    row += '<td>' + itemName + '</td>';
    row += '<td><input type="number" name="quantity[]" class="form-control" required></td>';
    row += '<td><input type="date" name="date[]" class="form-control" required></td>';
    row += '<td><input type="text" name="remarks[]" class="form-control"></td>';
    row += '<td><input type="hidden" name="s_id[]" value="' + itemId + '"><button type="button" class="btn btn-danger remove-item">Remove</button></td>';
    row += '</tr>';
    $('#items_info').append(row);
    $('#sug_input').val(''); // Clear the input after selecting
    $('#result').html(''); // Clear the result list
  });

  // Remove item from the table
  $(document).on('click', '.remove-item', function() {
    $(this).closest('tr').remove(); // Menghapus baris yang dipilih
  });
</script>