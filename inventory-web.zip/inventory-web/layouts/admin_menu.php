<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-cloud"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-menu-hamburger"></i>
      <span>User Management</span>
    </a>
    <ul class="nav submenu">
      <li><a href="group.php">Manage Groups</a> </li>
      <li><a href="users.php">Manage Users</a> </li>
    </ul>
  </li>
  <li>
    <a href="categorie.php">
      <i class="glyphicon glyphicon-list-alt"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-import"></i>
      <span>Items</span>
    </a>
    <ul class="nav submenu">
      <li><a href="items.php">Manage</a> </li>
      <li><a href="add_items.php">Add</a> </li>
      <li><a href="add_entryItem.php">Entry</a> </li>
    </ul>
  </li>
  <li>
    <a href="media.php">
      <i class="glyphicon glyphicon-paperclip"></i>
      <span>Media</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-export"></i>
      <span>Exit Items</span>
    </a>
    <ul class="nav submenu">
      <li><a href="exitItems.php">Manage</a> </li>
      <li><a href="add_exitItem.php">Add</a> </li>
    </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-floppy-disk"></i>
      <span>Report</span>
    </a>
    <ul class="nav submenu">
      <li><a href="exitItems_report.php">By date </a></li>
      <!-- <li><a href="monthly_exitItems.php">Monthly</a></li>
      <li><a href="daily_exitItems.php">Daily</a> </li> -->
    </ul>
  </li>
</ul>