<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-list"></i>
      <span>exitItems</span>
    </a>
    <ul class="nav submenu">
      <li><a href="exitItems.php">Manage exitItems</a> </li>
      <li><a href="add_exitItem.php">Add exitItem</a> </li>
    </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-signal"></i>
      <span>exitItems Report</span>
    </a>
    <ul class="nav submenu">
      <li><a href="exitItems_report.php">exitItems by dates </a></li>
      <li><a href="monthly_exitItems.php">Monthly exitItems</a></li>
      <li><a href="daily_exitItems.php">Daily exitItems</a> </li>
    </ul>
  </li>
</ul>