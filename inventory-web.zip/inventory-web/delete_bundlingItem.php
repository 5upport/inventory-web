<?php
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$d_bundlingItem = find_by_id('bundlingItems', (int)$_GET['id']);
if (!$d_bundlingItem) {
  $session->msg("d", "Missing bundlingItem id.");
  redirect('bundlingItems.php');
}
?>
<?php
$delete_id = delete_by_id('bundlingItems', (int)$d_bundlingItem['id']);
if ($delete_id) {
  $session->msg("s", "item deleted.");
  redirect('bundlingItems.php');
} else {
  $session->msg("d", "bundlingItem deletion failed.");
  redirect('bundlingItems.php');
}
?>
