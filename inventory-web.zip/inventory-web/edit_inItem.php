<?php
$page_title = 'Edit item';
require_once('includes/load.php');
page_require_level(3);
?>
<?php
$inItem = find_by_id('inItems', (int)$_GET['id']);
if (!$inItem) {
  $session->msg("d", "Missing items id.");
  redirect('inItems.php');
}
?>
<?php $items = find_by_id('itemss', $inItem['items_id']); ?>
<?php
if (isset($_POST['update_inItem'])) {
  $req_fields = array('title', 'quantity', 'date');
  validate_fields($req_fields);
  if (empty($errors)) {
    $p_id      = $db->escape((int)$items['id']);
    $s_qty     = $db->escape((int)$_POST['quantity']);
    $date      = $db->escape($_POST['date']);
    $s_date    = date("Y-m-d", strtotime($date));
    $s_rmk     = $db->escape($_POST['remarks']);
    $sql  = "UPDATE inItems SET";
    $sql .= " items_id= '{$p_id}',qty={$s_qty},price='{$s_total}',date='{$s_date}',rmk='{$s_rmk}'";
    $sql .= " WHERE id ='{$inItem['id']}'";
    $result = $db->query($sql);
    if ($result && $db->affected_rows() === 1) {
      update_items_qty($s_qty, $p_id);
      $session->msg('s', "inItem updated.");
      redirect('edit_inItem.php?id=' . $inItem['id'], false);
    } else {
      $session->msg('d', ' Sorry failed to updated!');
      redirect('inItems.php', false);
    }
  } else {
    $session->msg("d", $errors);
    redirect('edit_inItem.php?id=' . (int)$inItem['id'], false);
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel">
      <div class="panel-heading clearfix">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>All </span>
        </strong>
        <div class="pull-right">
          <a href="inItems.php" class="btn btn-primary">Show all</a>
        </div>
      </div>
      <div class="panel-body">
        <table class="table table-bordered">
          <thead>
            <th> Item title </th>
            <th> Qty </th>
            <th> Date</th>
            <th> Action</th>
            <th> Remarks</th>
          </thead>
          <tbody id="items_info">
            <tr>
              <form method="post" action="edit_inItem.php?id=<?php echo (int)$inItem['id']; ?>">
                <td id="s_name">
                  <input type="text" class="form-control" id="sug_input" name="title" value="<?php echo remove_junk($items['name']); ?>">
                  <div id="result" class="list-group"></div>
                </td>
                <td id="s_qty">
                  <input type="text" class="form-control" name="quantity" value="<?php echo (int)$inItem['qty']; ?>">
                </td>
                <td id="s_date">
                  <input type="date" class="form-control" name="date" data-date-format="" value="<?php echo remove_junk($inItem['date']); ?>">
                </td>
                <td>
                  <button type="submit" name="update_inItem" class="btn btn-primary">Update Item</button>
                </td>
                <td id="s_rmk">
                  <input type="text" class="form-control" name="remarks" value="<?php echo remove_junk($inItem['rmk']); ?>">
                </td>
              </form>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>